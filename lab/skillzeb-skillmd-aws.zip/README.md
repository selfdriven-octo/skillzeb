# Skillzeb → SKILL.md (AWS Lambda + API Gateway)

Serverless MCP-style server that converts a Skillzeb JSON template into a `SKILL.md`, plus an inline drag‑and‑drop UI.

## Deploy (AWS SAM)

Prereqs: AWS account, AWS CLI, SAM CLI configured.

```bash
sam build
sam deploy --guided
# accept defaults; note the ApiEndpoint output
```

## Endpoints

- `GET /mcp` — tool + UI descriptor (for ChatGPT Apps “Connector URL”)
- `POST /mcp/call_tool` — run the converter (args: `{ name, arguments: { url } | { json } }`)
- `GET /ui/skillmd.html` — drag‑and‑drop offline UI

## Test locally (SAM)

```bash
sam local start-api
# then: http://127.0.0.1:3000/ui/skillmd.html
```

## Connect from ChatGPT (Developer Mode)

Use the **Connector URL**: `https://<ApiEndpoint>/mcp` in the Apps settings.
