// src/index.js
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "content-type",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
};

const esc = (s) => String(s ?? "").replace(/\r?\n+/g, " ").trim();
const coalesce = (...args) => args.find((v) => v != null && String(v).trim() !== "") ?? "";
const yamlEscape = (s) => {
  const str = String(s ?? "");
  return /[:\-\?\[\]\{\}\n\r#,&*!|>'"%@`]/.test(str) ? JSON.stringify(str) : str;
};
const isoDate = () => new Date().toISOString().slice(0,10);

function toMarkdown(def) {
  const title = coalesce(def.title, def.name, "Skill");
  const summary = coalesce(def.summary, def.usage, def.description);
  const versionNum = def.version?.number || "";
  const versionDate = def.version?.date || "";
  const sourceUrl = def.source?.url || "";
  const license = def.source?.sharing?.type || def.sharing?.type || def.source?.license || "";
  const domains = Array.isArray(def.domains) ? def.domains : [];
  const resources = Array.isArray(def.resources) ? def.resources : [];
  const sharing = def.sharing || {};

  let front =
    `---\n` +
    `name: ${yamlEscape(title)}\n` +
    `description: ${yamlEscape(esc(summary))}\n` +
    ((versionNum || versionDate) ? `version: ${yamlEscape(versionNum + (versionDate ? " ("+versionDate+")" : ""))}\n` : "") +
    (sourceUrl ? `source: ${yamlEscape(sourceUrl)}\n` : "") +
    (license ? `license: ${yamlEscape(license)}\n` : "") +
    `---\n\n`;

  let md = `# ${title}\n\n`;
  if (summary) md += `**TL;DR:** ${esc(summary)}\n\n`;
  if (def.usage) md += `## Usage\n\n${def.usage}\n\n`;
  if (def.description) md += `## Description\n\n${def.description}\n\n`;

  if (domains.length) {
    md += `## Domains\n\n${domains.map(d => "- " + esc(d)).join("\n")}\n\n`;
  }

  if (resources.length) {
    md += `## Resources\n\n| Subject | For | URL |\n|---|---|---|\n`;
    resources.forEach(r => {
      const subj = esc(r.subject);
      const forList = Array.isArray(r.for) ? r.for.join(", ") : esc(r.for);
      const url = esc(r.url);
      md += `| ${subj} | ${forList} | ${url} |\n`;
    });
    md += `\n`;
  }

  const shareType = sharing.type || "";
  const shareDesc = sharing.description || "";
  if (shareType || shareDesc || (sharing.resources?.length ?? 0) > 0) {
    md += `## Sharing & Attribution\n\n`;
    if (shareType) md += `- **Type:** ${esc(shareType)}\n`;
    if (shareDesc) md += `- **Description:** ${esc(shareDesc)}\n`;
    if (sharing.resources?.length) {
      md += `- **Assets:**\n`;
      sharing.resources.forEach(x => {
        const t = esc(x.type || "resource");
        const u = esc(x.url || x.imageURL || "");
        if (u) md += `  - ${t}: ${u}\n`;
      });
    }
    md += `\n`;
  }

  md += `---\nUpdated: ${isoDate()}\n`;
  return front + md;
}

const UI_HTML = `<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  :root { --fg:#111; --bg:#fafafa; --muted:#666; --accent:#0a7; --border:#ddd; }
  html,body { margin:0; background:var(--bg); color:var(--fg); font:14px/1.45 system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif; }
  .wrap { padding:16px; max-width:900px; margin:0 auto; }
  h1 { font-size:18px; margin:0 0 8px; }
  .row { display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin:10px 0; }
  input[type="text"] { flex:1; min-width:240px; padding:8px 10px; border:1px solid var(--border); border-radius:10px; background:#fff; }
  button { padding:8px 12px; border:1px solid var(--border); border-radius:10px; background:#fff; cursor:pointer; }
  button.primary { background:var(--accent); color:#fff; border-color:transparent; }
  .drop { border:2px dashed var(--border); border-radius:12px; padding:18px; text-align:center; color:var(--muted); transition:.2s border-color,.2s background; background:#fff; }
  .drop.drag { border-color:var(--accent); background:#f2fffb; color:#0b6; }
  .hint { color:var(--muted); font-size:12px; }
  textarea { width:100%; min-height:300px; border:1px solid var(--border); border-radius:10px; padding:10px 12px; background:#fff; }
</style>
</head>
<body>
<div class="wrap">
  <h1>Skillzeb → SKILL.md</h1>
  <div class="row">
    <input id="url" type="text" placeholder="https://…/skillzeb.template.json (optional)" />
    <button id="btnUrl">Fetch URL → Convert (local)</button>
  </div>

  <div id="drop" class="drop">⬇️ Drag & drop a Skillzeb <strong>.json</strong> file here</div>
  <div class="row">
    <input id="file" type="file" accept="application/json,.json" />
    <button id="btnFile" class="primary">Convert File (local)</button>
    <button id="btnDownload" disabled>Download SKILL.md</button>
  </div>
  <p class="hint">Local conversion happens entirely in your browser.</p>

  <textarea id="out" readonly placeholder="Generated SKILL.md preview will appear here…"></textarea>
</div>

<script>
(function () {
  const $ = (s) => document.querySelector(s);
  const urlInput = $("#url");
  const btnUrl = $("#btnUrl");
  const drop = $("#drop");
  const fileInput = $("#file");
  const btnFile = $("#btnFile");
  const btnDownload = $("#btnDownload");
  const out = $("#out");

  const coalesce = (...args) => args.find(v => v != null && String(v).trim() !== "") ?? "";
  const esc = (s) => String(s ?? "").replace(/\\r?\\n+/g, " ").trim();
  const yamlEscape = (s) => { const str = String(s ?? ""); return /[:\\-\\?\\[\\]\\{\\}\\n\\r#,&*!|>'"%@`]/.test(str) ? JSON.stringify(str) : str; };
  const isoDate = () => new Date().toISOString().slice(0,10);

  function toMarkdown(def) {
    const title = coalesce(def.title, def.name, "Skill");
    const summary = coalesce(def.summary, def.usage, def.description);
    const versionNum = def.version?.number || "";
    const versionDate = def.version?.date || "";
    const sourceUrl = def.source?.url || "";
    const license = def.source?.sharing?.type || def.sharing?.type || def.source?.license || "";
    const domains = Array.isArray(def.domains) ? def.domains : [];
    const resources = Array.isArray(def.resources) ? def.resources : [];
    const sharing = def.sharing || {};

    let front =
      \`---\\n\` +
      \`name: \${yamlEscape(title)}\\n\` +
      \`description: \${yamlEscape(esc(summary))}\\n\` +
      ((versionNum || versionDate) ? \`version: \${yamlEscape(versionNum + (versionDate ? " ("+versionDate+")" : ""))}\\n\` : "") +
      (sourceUrl ? \`source: \${yamlEscape(sourceUrl)}\\n\` : "") +
      (license ? \`license: \${yamlEscape(license)}\\n\` : "") +
      \`---\\n\\n\`;

    let md = \`# \${title}\\n\\n\`;
    if (summary) md += \`**TL;DR:** \${esc(summary)}\\n\\n\`;
    if (def.usage) md += \`## Usage\\n\\n\${def.usage}\\n\\n\`;
    if (def.description) md += \`## Description\\n\\n\${def.description}\\n\\n\`;

    if (domains.length) {
      md += \`## Domains\\n\\n\${domains.map(d => "- " + esc(d)).join("\\n")}\\n\\n\`;
    }

    if (resources.length) {
      md += \`## Resources\\n\\n| Subject | For | URL |\\n|---|---|---|\\n\`;
      resources.forEach(r => {
        const subj = esc(r.subject);
        const forList = Array.isArray(r.for) ? r.for.join(", ") : esc(r.for);
        const url = esc(r.url);
        md += \`| \${subj} | \${forList} | \${url} |\\n\`;
      });
      md += \`\\n\`;
    }

    const shareType = sharing.type || "";
    const shareDesc = sharing.description || "";
    if (shareType || shareDesc || (sharing.resources?.length ?? 0) > 0) {
      md += \`## Sharing & Attribution\\n\\n\`;
      if (shareType) md += \`- **Type:** \${esc(shareType)}\\n\`;
      if (shareDesc) md += \`- **Description:** \${esc(shareDesc)}\\n\`;
      if (sharing.resources?.length) {
        md += \`- **Assets:**\\n\`;
        sharing.resources.forEach(x => {
          const t = esc(x.type || "resource");
          const u = esc(x.url || x.imageURL || "");
          if (u) md += \`  - \${t}: \${u}\\n\`;
        });
      }
      md += \`\\n\`;
    }

    md += \`---\\nUpdated: \${isoDate()}\\n\`;
    return front + md;
  }

  function parseTemplate(jsonText) {
    let obj;
    try { obj = JSON.parse(jsonText); }
    catch (e) { throw new Error("Invalid JSON: " + e.message); }
    const def = obj?.template?.definition;
    if (!def) throw new Error("Invalid Skillzeb template format (missing template.definition)");
    return def;
  }

  function show(md) { out.value = md; btnDownload.disabled = !md; }
  function download(md) {
    const blob = new Blob([md], { type: "text/markdown" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "SKILL.md";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 500);
  }

  async function convertText(jsonText) {
    const def = parseTemplate(jsonText);
    const md = toMarkdown(def);
    show(md);
  }

  ["dragenter","dragover"].forEach(ev =>
    drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add("drag"); })
  );
  ["dragleave","drop"].forEach(ev =>
    drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove("drag"); })
  );
  drop.addEventListener("drop", (e) => {
    const file = e.dataTransfer.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => convertText(String(reader.result || ""));
    reader.readAsText(file, "utf-8");
  });

  btnFile.addEventListener("click", () => {
    const f = fileInput.files?.[0];
    if (!f) { show("Choose a JSON file first."); return; }
    const r = new FileReader();
    r.onload = () => convertText(String(r.result || ""));
    r.readAsText(f, "utf-8");
  });

  btnUrl.addEventListener("click", async () => {
    const u = urlInput.value.trim();
    if (!u) { show("Enter a URL."); return; }
    try {
      const res = await fetch(u);
      if (!res.ok) throw new Error(`Fetch failed: HTTP ${res.status}`);
      const text = await res.text();
      await convertText(text);
    } catch (e) {
      show("❌ " + (e?.message || e));
      console.error(e);
    }
  });

  btnDownload.addEventListener("click", () => { if (out.value) download(out.value); });
})();
</script>
</body></html>`;

function jsonResponse(body, statusCode = 200) {
  return {
    statusCode,
    headers: { "content-type": "application/json; charset=utf-8", ...CORS },
    body: JSON.stringify(body)
  };
}
function htmlResponse(html, statusCode = 200) {
  return {
    statusCode,
    headers: { "content-type": "text/html; charset=utf-8", ...CORS },
    body: html
  };
}

exports.handler = async (event) => {
  const method = event.requestContext?.http?.method || event.httpMethod || "GET";
  const rawPath = event.requestContext?.http?.path || event.rawPath || event.path || "/";
  const path = rawPath.replace(/\/+$/,''); // trim trailing slash

  if (method === "OPTIONS") return { statusCode: 204, headers: CORS, body: "" };

  if (method === "GET" && path === "/mcp") {
    return jsonResponse({
      name: "skillzeb-skillmd",
      version: "1.0.0",
      tools: [{
        name: "convert_skillzeb_to_skillmd",
        title: "Convert Skillzeb JSON to SKILL.md",
        description: "Provide a URL to JSON or raw JSON. Returns markdown and renders a preview UI.",
        inputSchema: {
          type: "object",
          properties: { url: { type: "string", format: "uri" }, json: { type: "string" } },
          oneOf: [{ required: ["url"] }, { required: ["json"] }]
        },
        component: { uri: "ui://skillmd/preview" },
        outputSchema: {
          type: "object",
          properties: { markdown: { type: "string" }, filename: { type: "string" } },
          required: ["markdown", "filename"]
        }
      }],
      resources: [{ uri: "ui://skillmd/preview", mimeType: "text/html+skybridge", href: "/ui/skillmd.html" }]
    });
  }

  if (method === "POST" && path === "/mcp/call_tool") {
    let bodyText = event.body || "";
    if (event.isBase64Encoded) bodyText = Buffer.from(bodyText, "base64").toString("utf8");
    let payload = {}; try { payload = JSON.parse(bodyText || "{}"); } catch {}
    const { name, arguments: args } = payload;
    if (name !== "convert_skillzeb_to_skillmd") return jsonResponse({ error: "Unknown tool" }, 404);
    const url = typeof args?.url === "string" ? args.url : undefined;
    const rawJson = typeof args?.json === "string" ? args.json : undefined;
    if (!url && !rawJson) return jsonResponse({ error: "Provide either url or json" }, 400);

    try {
      let text;
      if (rawJson) {
        text = rawJson;
      } else {
        const r = await fetch(url);
        if (!r.ok) throw new Error("Fetch failed: " + r.status);
        text = await r.text();
      }
      const obj = JSON.parse(text);
      const def = obj?.template?.definition;
      if (!def) throw new Error("Invalid Skillzeb template format: expected template.definition");

      const markdown = toMarkdown(def);
      return jsonResponse({
        content: { markdown, filename: "SKILL.md" },
        annotations: { componentProps: { preview: markdown, filename: "SKILL.md" } }
      });
    } catch (e) {
      return jsonResponse({ error: String(e && e.message || e) }, 400);
    }
  }

  if (method === "GET" && path === "/ui/skillmd.html") {
    return htmlResponse(UI_HTML);
  }

  return jsonResponse({ error: "Not found", path, method }, 404);
};
