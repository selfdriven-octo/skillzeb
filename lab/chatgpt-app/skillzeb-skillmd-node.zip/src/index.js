// src/index.js
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "content-type",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
};

const esc = (s) => String(s ?? "").replace(/\r?\n+/g, " ").trim();
const coalesce = (...args) => args.find((v) => v != null && String(v).trim() !== "") ?? "";
const yamlEscape = (s) => {
  const str = String(s ?? "");
  return /[:\-\?\[\]\{\}\n\r#,&*!|>'"%@`]/.test(str) ? JSON.stringify(str) : str;
};
const isoDate = () => new Date().toISOString().slice(0,10);

function toMarkdown(def) {
  const title = coalesce(def.title, def.name, "Skill");
  const summary = coalesce(def.summary, def.usage, def.description);
  const versionNum = def.version?.number || "";
  const versionDate = def.version?.date || "";
  const sourceUrl = def.source?.url || "";
  const license = def.source?.sharing?.type || def.sharing?.type || def.source?.license || "";
  const domains = Array.isArray(def.domains) ? def.domains : [];
  const resources = Array.isArray(def.resources) ? def.resources : [];
  const sharing = def.sharing || {};

  let front =
    `---\n` +
    `name: ${yamlEscape(title)}\n` +
    `description: ${yamlEscape(esc(summary))}\n` +
    ((versionNum || versionDate) ? `version: ${yamlEscape(versionNum + (versionDate ? " ("+versionDate+")" : ""))}\n` : "") +
    (sourceUrl ? `source: ${yamlEscape(sourceUrl)}\n` : "") +
    (license ? `license: ${yamlEscape(license)}\n` : "") +
    `---\n\n`;

  let md = `# ${title}\n\n`;
  if (summary) md += `**TL;DR:** ${esc(summary)}\n\n`;
  if (def.usage) md += `## Usage\n\n${def.usage}\n\n`;
  if (def.description) md += `## Description\n\n${def.description}\n\n`;

  if (domains.length) {
    md += `## Domains\n\n${domains.map(d => "- " + esc(d)).join("\n")}\n\n`;
  }

  if (resources.length) {
    md += `## Resources\n\n| Subject | For | URL |\n|---|---|---|\n`;
    resources.forEach(r => {
      const subj = esc(r.subject);
      const forList = Array.isArray(r.for) ? r.for.join(", ") : esc(r.for);
      const url = esc(r.url);
      md += `| ${subj} | ${forList} | ${url} |\n`;
    });
    md += `\n`;
  }

  const shareType = sharing.type || "";
  const shareDesc = sharing.description || "";
  if (shareType || shareDesc || (sharing.resources?.length ?? 0) > 0) {
    md += `## Sharing & Attribution\n\n`;
    if (shareType) md += `- **Type:** ${esc(shareType)}\n`;
    if (shareDesc) md += `- **Description:** ${esc(shareDesc)}\n`;
    if (sharing.resources?.length) {
      md += `- **Assets:**\n`;
      sharing.resources.forEach(x => {
        const t = esc(x.type || "resource");
        const u = esc(x.url || x.imageURL || "");
        if (u) md += `  - ${t}: ${u}\n`;
      });
    }
    md += `\n`;
  }

  md += `---\nUpdated: ${isoDate()}\n`;
  return front + md;
}

function jsonResponse(body, statusCode = 200) {
  return {
    statusCode,
    headers: { "content-type": "application/json; charset=utf-8", ...CORS },
    body: JSON.stringify(body)
  };
}

exports.handler = async (event) => {
  const method = event.httpMethod || "GET";
  const path = (event.path || "/").replace(/\/+$/, "");

  if (method === "OPTIONS") return { statusCode: 204, headers: CORS, body: "" };

  if (method === "GET" && path === "/mcp") {
    return jsonResponse({
      name: "skillzeb-skillmd",
      version: "1.0.0",
      tools: [{
        name: "convert_skillzeb_to_skillmd",
        title: "Convert Skillzeb JSON to SKILL.md",
        description: "Provide a URL or JSON. Returns markdown.",
        inputSchema: {
          type: "object",
          properties: { url: { type: "string" }, json: { type: "string" } },
          oneOf: [{ required: ["url"] }, { required: ["json"] }]
        },
        outputSchema: {
          type: "object",
          properties: { markdown: { type: "string" } },
          required: ["markdown"]
        }
      }]
    });
  }

  if (method === "POST" && path === "/mcp/call_tool") {
    let bodyText = event.body || "";
    if (event.isBase64Encoded) bodyText = Buffer.from(bodyText, "base64").toString("utf8");
    let payload = {}; try { payload = JSON.parse(bodyText || "{}"); } catch {}
    const args = payload.arguments || {};
    const url = args.url;
    const rawJson = args.json;

    try {
      let text = rawJson;
      if (url && !rawJson) {
        const res = await fetch(url);
        if (!res.ok) throw new Error("Fetch failed: " + res.status);
        text = await res.text();
      }
      const obj = JSON.parse(text);
      const def = obj?.template?.definition;
      if (!def) throw new Error("Invalid Skillzeb template format");
      const markdown = toMarkdown(def);
      return jsonResponse({ markdown });
    } catch (e) {
      return jsonResponse({ error: e.message || String(e) }, 400);
    }
  }

  if (method === "GET" && path === "/ui/skillmd.html") {
    return {
      statusCode: 200,
      headers: { "content-type": "text/html; charset=utf-8", ...CORS },
      body: "<h1>Skillzeb → SKILL.md UI ready</h1>"
    };
  }

  return jsonResponse({ error: "Not found" }, 404);
};
